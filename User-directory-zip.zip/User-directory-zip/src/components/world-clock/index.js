import React, { useState, useEffect } from "react";
import "./styles/index.scss";

const WorldClock = () => {
  const [countries, setCountries] = useState([]);
  const [selectedCountry, setSelectedCountry] = useState("America/New_York");
  const [currentTime, setCurrentTime] = useState(null);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    fetch("http://worldtimeapi.org/api/timezone")
      .then((res) => res.json())
      .then((data) => setCountries(data))
      .catch((error) => console.error("Error fetching countries:", error));
  }, []);

  useEffect(() => {
    const fetchInitialTime = async () => {
      try {
        const response = await fetch(
          `http://worldtimeapi.org/api/timezone/${selectedCountry}`
        );
        const data = await response.json();
        setCurrentTime(new Date(data.utc_datetime));
      } catch (error) {
        console.error("Error fetching current time:", error);
      }
    };

    fetchInitialTime();
  }, [selectedCountry]);

  useEffect(() => {
    const intervalId = setInterval(() => {
      if (!isPaused) {
        setCurrentTime((prevTime) => {
          const newTime = new Date(prevTime);
          newTime.setSeconds(newTime.getSeconds() + 1);
          return newTime;
        });
      }
    }, 1000);

    return () => clearInterval(intervalId);
  }, [isPaused]);

  const formatTime = (time) => {
    const options = {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      hour12: false,
      timeZone: selectedCountry,
    };
    return time.toLocaleTimeString("en-US", options);
  };

  const handlePauseToggle = () => {
    setIsPaused((prevState) => !prevState);
  };

  return (
    <div className="world-clock">
      <select
        id="countrySelector"
        onChange={(e) => {
          setSelectedCountry(e.target.value);
        }}
        value={selectedCountry}
      >
        <option value="" disabled>
          Select a country
        </option>
        {countries.map((country, index) => (
          <option key={index} value={country}>
            {country}
          </option>
        ))}
      </select>

      <div className="clock">
        <p>{currentTime && formatTime(currentTime)}</p>
        <button onClick={handlePauseToggle}>
          {isPaused ? "Start" : "Pause"}
        </button>
      </div>
    </div>
  );
};

export default WorldClock;
