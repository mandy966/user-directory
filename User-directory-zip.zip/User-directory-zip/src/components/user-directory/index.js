import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "./styles/index.scss";

const UserDirectory = () => {
  const [users, setUsers] = useState([]);
  const [totalPosts, setTotalPosts] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((res) => res.json())
      .then((data) => {
        setUsers(data);
        data.forEach((user) => {
          fetch(`https://jsonplaceholder.typicode.com/posts?userId=${user.id}`)
            .then((res) => res.json())
            .then((posts) => {
              setTotalPosts(posts.length);
            })
            .catch((error) =>
              console.error("Error fetching user posts:", error)
            ).finally(()=>{
              setIsLoading(false)
            });
        });
      })
      .catch((error) => console.error("Error fetching users:", error));
  }, []);

  return (
    <div>
      {
        isLoading ?
          <div className="loadingContainer">
            <h1 className="loadingText">Loading...</h1>
          </div> : <div className="user-directory">
            <h2>Directory</h2>
            {users.map((user) => (
              <Link to={`/profile/${user.id}`}>
                <div className="user-card">
                  <p>Name: {user.name}</p>
                  <p>Posts: {totalPosts ? totalPosts : "..."}</p>
                </div>
              </Link>
            ))}
          </div>
      }
    </div>
  );
};

export default UserDirectory;
