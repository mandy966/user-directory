import React, { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import WorldClock from "../world-clock";
import axios from "axios";
import "./styles/index.scss";

const UserProfile = () => {
  const { userId } = useParams();
  const [user, setUser] = useState(null);
  const [posts, setPosts] = useState([]);
  const [isLoading, setIsLoading] = useState(true)

  const initData = async() =>{
    try{
      const userData = await axios.get(`https://jsonplaceholder.typicode.com/users/${userId}`)
      const userPostData = await axios.get(`https://jsonplaceholder.typicode.com/posts?userId=${userId}`)
      setUser(userData.data);
      setPosts(userPostData.data)
    }catch(error){
      console.log("Error while fetching the data", error)
    }finally{
      setIsLoading(false);
    }
  }

  useEffect(() => {
    initData()
  }, [userId]);

  return (
    <div>
      {
        isLoading ?
        <div className="loadingContainer">
        <h1 className="loadingText">Loading....</h1>
      </div> :
          <div className="profile">
            <div className="profile-header">
              <Link to="/">
                <button>Back</button>
              </Link>
              <WorldClock />
            </div>

            <h2>Profile Page</h2>

            {user && (
              <div>
                <div className="profile-details">
                  <div className="profile-details_section1">
                    <p>{user.name}</p>
                    <p>
                      {user.username} | {user.company.catchPhrase}
                    </p>
                  </div>

                  <div className="profile-details_section2">
                    <p>{user.address.street}</p>
                    <p>
                      {user.email} | {user.phone}
                    </p>
                  </div>
                </div>

                <div className="posts">
                  {posts.map((post) => (
                    <div key={post.id} className="post">
                      <h4>{post.title}</h4>
                      <p>{post.body}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
      }
    </div>
  );
};

export default UserProfile;
