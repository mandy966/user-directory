import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import UserDirectory from './components/user-directory';
import UserProfile from './components/user-profile';
function App() {
  return (
    <Router>
      <Routes>
        <Route path='/' element={<UserDirectory/>}/>
        <Route path='/profile/:userId' element={<UserProfile/>}/>
      </Routes>
    </Router>
  );
}

export default App;
